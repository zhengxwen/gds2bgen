$(document).ready(
	function() {
		// $( '.collapsible' ).fadeOut() ;
	}
) ;